﻿namespace Polinomios
{
    partial class FrmPolinomios
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            txtCoeficiente = new TextBox();
            label2 = new Label();
            label3 = new Label();
            txtExponente = new TextBox();
            cmbPolinomio = new ComboBox();
            btnAgregar = new Button();
            lblPolinomio1 = new Label();
            lblPolinomio2 = new Label();
            lblPolinomioR = new Label();
            btnCalcular = new Button();
            cmbOperacion = new ComboBox();
            btnLimpiar = new Button();
            lblPolinomioRR = new Label();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(51, 95);
            label1.Name = "label1";
            label1.Size = new Size(84, 20);
            label1.TabIndex = 0;
            label1.Text = "Coeficiente";
            // 
            // txtCoeficiente
            // 
            txtCoeficiente.Location = new Point(141, 89);
            txtCoeficiente.Margin = new Padding(3, 4, 3, 4);
            txtCoeficiente.Name = "txtCoeficiente";
            txtCoeficiente.Size = new Size(114, 27);
            txtCoeficiente.TabIndex = 1;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Times New Roman", 36F, FontStyle.Italic, GraphicsUnit.Point, 0);
            label2.Location = new Point(262, 53);
            label2.Name = "label2";
            label2.Size = new Size(56, 68);
            label2.TabIndex = 2;
            label2.Text = "x";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(208, 53);
            label3.Name = "label3";
            label3.Size = new Size(79, 20);
            label3.TabIndex = 3;
            label3.Text = "Exponente";
            // 
            // txtExponente
            // 
            txtExponente.Location = new Point(303, 43);
            txtExponente.Margin = new Padding(3, 4, 3, 4);
            txtExponente.Name = "txtExponente";
            txtExponente.Size = new Size(114, 27);
            txtExponente.TabIndex = 4;
            // 
            // cmbPolinomio
            // 
            cmbPolinomio.FormattingEnabled = true;
            cmbPolinomio.Items.AddRange(new object[] { "Polinomio 1", "Polinomio 2" });
            cmbPolinomio.Location = new Point(435, 84);
            cmbPolinomio.Margin = new Padding(3, 4, 3, 4);
            cmbPolinomio.Name = "cmbPolinomio";
            cmbPolinomio.Size = new Size(138, 28);
            cmbPolinomio.TabIndex = 5;
            // 
            // btnAgregar
            // 
            btnAgregar.Location = new Point(606, 91);
            btnAgregar.Margin = new Padding(3, 4, 3, 4);
            btnAgregar.Name = "btnAgregar";
            btnAgregar.Size = new Size(86, 31);
            btnAgregar.TabIndex = 6;
            btnAgregar.Text = "Agregar";
            btnAgregar.UseVisualStyleBackColor = true;
            btnAgregar.Click += btnAgregar_Click;
            // 
            // lblPolinomio1
            // 
            lblPolinomio1.BackColor = Color.SteelBlue;
            lblPolinomio1.Location = new Point(-1, 143);
            lblPolinomio1.Name = "lblPolinomio1";
            lblPolinomio1.Size = new Size(911, 115);
            lblPolinomio1.TabIndex = 7;
            // 
            // lblPolinomio2
            // 
            lblPolinomio2.BackColor = Color.SteelBlue;
            lblPolinomio2.Location = new Point(-1, 273);
            lblPolinomio2.Name = "lblPolinomio2";
            lblPolinomio2.Size = new Size(911, 115);
            lblPolinomio2.TabIndex = 8;
            // 
            // lblPolinomioR
            // 
            lblPolinomioR.BackColor = Color.Bisque;
            lblPolinomioR.Location = new Point(-1, 473);
            lblPolinomioR.Name = "lblPolinomioR";
            lblPolinomioR.Size = new Size(911, 115);
            lblPolinomioR.TabIndex = 9;
            // 
            // btnCalcular
            // 
            btnCalcular.Location = new Point(42, 413);
            btnCalcular.Margin = new Padding(3, 4, 3, 4);
            btnCalcular.Name = "btnCalcular";
            btnCalcular.Size = new Size(86, 31);
            btnCalcular.TabIndex = 10;
            btnCalcular.Text = "Calcular";
            btnCalcular.UseVisualStyleBackColor = true;
            btnCalcular.Click += btnCalcular_Click;
            // 
            // cmbOperacion
            // 
            cmbOperacion.FormattingEnabled = true;
            cmbOperacion.Items.AddRange(new object[] { "Suma", "Resta", "Multiplicación", "División", "Derivada" });
            cmbOperacion.Location = new Point(175, 413);
            cmbOperacion.Margin = new Padding(3, 4, 3, 4);
            cmbOperacion.Name = "cmbOperacion";
            cmbOperacion.Size = new Size(164, 28);
            cmbOperacion.TabIndex = 11;
            cmbOperacion.SelectedIndexChanged += cmbOperacion_SelectedIndexChanged;
            // 
            // btnLimpiar
            // 
            btnLimpiar.Location = new Point(715, 88);
            btnLimpiar.Margin = new Padding(3, 4, 3, 4);
            btnLimpiar.Name = "btnLimpiar";
            btnLimpiar.Size = new Size(86, 31);
            btnLimpiar.TabIndex = 12;
            btnLimpiar.Text = "Limpiar";
            btnLimpiar.UseVisualStyleBackColor = true;
            btnLimpiar.Click += btnLimpiar_Click;
            // 
            // lblPolinomioRR
            // 
            lblPolinomioRR.BackColor = Color.Khaki;
            lblPolinomioRR.Location = new Point(-1, 605);
            lblPolinomioRR.Name = "lblPolinomioRR";
            lblPolinomioRR.Size = new Size(911, 115);
            lblPolinomioRR.TabIndex = 13;
            // 
            // FrmPolinomios
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(914, 761);
            Controls.Add(lblPolinomioRR);
            Controls.Add(btnLimpiar);
            Controls.Add(cmbOperacion);
            Controls.Add(btnCalcular);
            Controls.Add(lblPolinomioR);
            Controls.Add(lblPolinomio2);
            Controls.Add(lblPolinomio1);
            Controls.Add(btnAgregar);
            Controls.Add(cmbPolinomio);
            Controls.Add(txtExponente);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(txtCoeficiente);
            Controls.Add(label1);
            Margin = new Padding(3, 4, 3, 4);
            Name = "FrmPolinomios";
            Text = "Operaciones con Polinomios";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private TextBox txtCoeficiente;
        private Label label2;
        private Label label3;
        private TextBox txtExponente;
        private ComboBox cmbPolinomio;
        private Button btnAgregar;
        private Label lblPolinomio1;
        private Label lblPolinomio2;
        private Label lblPolinomioR;
        private Button btnCalcular;
        private ComboBox cmbOperacion;
        private Button btnLimpiar;
        private Label lblPolinomioRR;
    }
}
